package com.citius.servicex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicexApplicationTests {

	@Test
	void contextLoads() {
	}

}
